// +build !cgo

package graphdb

// NewSqliteConn return a new sqlite connection.
func NewSqliteConn(root string) (*Database, error) {
	panic("Not implemented")
}
