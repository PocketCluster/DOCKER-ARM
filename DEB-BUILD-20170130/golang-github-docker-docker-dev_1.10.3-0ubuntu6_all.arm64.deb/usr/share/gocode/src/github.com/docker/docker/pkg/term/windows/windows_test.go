// This file is necessary to pass the Docker tests.

package windows
