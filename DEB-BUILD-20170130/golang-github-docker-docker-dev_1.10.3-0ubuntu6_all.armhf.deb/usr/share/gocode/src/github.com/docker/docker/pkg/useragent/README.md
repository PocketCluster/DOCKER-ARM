This package provides helper functions to pack version information into a single User-Agent header.
