docker.go contains Docker's main function.

This file provides first line CLI argument parsing and environment variable setting.
