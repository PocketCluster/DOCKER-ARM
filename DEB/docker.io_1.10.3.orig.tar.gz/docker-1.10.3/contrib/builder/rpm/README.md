# `dockercore/builder-rpm`

This image's tags contain the dependencies for building Docker `.rpm`s for each of the RPM-based platforms Docker targets.

To add new tags, see [`contrib/builder/rpm` in https://github.com/docker/docker](https://github.com/docker/docker/tree/master/contrib/builder/rpm), specifically the `generate.sh` script, whose usage is described in a comment at the top of the file.
