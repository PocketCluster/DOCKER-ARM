package register

import (
	// register vfs
	_ "github.com/docker/docker/daemon/graphdriver/vfs"
)
