// +build !linux

package template
