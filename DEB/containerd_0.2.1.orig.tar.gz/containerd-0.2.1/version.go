package containerd

const Version = "0.1.0"

var GitCommit = ""
