// +build cgo,windows

package graphdb

import (
	_ "github.com/mattn/go-sqlite3" // registers sqlite
)
