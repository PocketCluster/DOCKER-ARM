package mount

func parseMountTable() ([]*Info, error) {
	// Do NOT return an error!
	return nil, nil
}
