package supervisor

type Machine struct {
	Cpus   int
	Memory int64
}
